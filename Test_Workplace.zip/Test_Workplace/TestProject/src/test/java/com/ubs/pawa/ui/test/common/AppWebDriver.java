package com.ubs.pawa.ui.test.common;

import java.io.File;
import java.net.URISyntaxException;
import java.net.URL;
import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;


public class AppWebDriver {

	public WebDriver driver;

	// Load local driver
	public WebDriver loadAndLaunchApp() throws URISyntaxException {

		URL fileUrl = AppWebDriver.class.getResource(AppWebElements.getPropertyValue("ie.driver.path").trim());

		Assert.assertNotNull("IE Driver Server file missing", fileUrl);

		File file = new File(fileUrl.toURI());

		System.setProperty("webdriver.ie.driver", file.getAbsolutePath());

		System.out.println("Loading web driver......");

		driver = new InternetExplorerDriver();

		System.out.println("Launching application.");
		
		driver.get(AppWebElements.getPropertyValue("target.url").trim());
		
		driver.manage().window().maximize();

		return driver;
	}

	// Release driver
	public void releaseDriver() throws InterruptedException {

		if (null != driver) {

			System.out.println("Clear cookies.");

			driver.manage().deleteAllCookies();

			System.out.println("Stop driver.");

			driver.close();

			driver.quit();
		}
	}	
}
