package com.ubs.pawa.ui.test.selenium;

import java.util.Collections;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.ubs.pawa.ui.test.common.AppConstants;
import com.ubs.pawa.ui.test.common.AppWebElements;

public class HomePage {
	
	private final WebDriver driver;
	
	AppWebElements appWebElements = new AppWebElements();
	
	public List<Map<String, String>> list = Collections.emptyList();

	public HomePage(WebDriver driver) {
		this.driver = driver;
	}

	public void setFromDate(String fromDate) {
		driver.findElement(By.id("fromDate")).clear();
		driver.findElement(By.id("fromDate")).sendKeys(fromDate);
	}
	
	public void setToDate(String toDate) {
		driver.findElement(By.id("toDate")).clear();
		driver.findElement(By.id("toDate")).sendKeys(toDate);
	}
	
	public void submitRequest() {
		driver.findElement(By.id("go")).click();		
		acceptAlert();
	}
	
	public void acceptAlert() {

		WebDriverWait wait = new WebDriverWait(driver, 2);

		wait.until(ExpectedConditions.alertIsPresent());

		driver.switchTo().alert().accept();		
	}
	
	public void viewLots(){
		driver.findElement(By.xpath("//*[contains(@id, '_toggleTransactionLink')]")).click();
	}

	public void updateLotDetails(String fileName) {

		list = appWebElements.readInputFile(fileName);

		if (null != list && !list.isEmpty())
			AppWebElements.updateValues(driver, list);
	}
	
	public void transferLots(String transferLots, String accNum){
		
		if (StringUtils.isNotBlank(transferLots) && AppConstants.TRANSFER_LOTS_YES.equalsIgnoreCase(transferLots)){

			driver.findElement(By.id("yesAnswer")).click();
			updateOtherAccNum(accNum);
			
		}else{
			driver.findElement(By.id("noAnswer")).click();
		}
	}
	
	public void updateOtherAccNum(String accNum) {
		
		if (StringUtils.isNotBlank(accNum)) {
			
			String[] accNums = accNum.split(",");
			
			int size = accNums.length;
			
			System.out.println("accNums length----------"+size);
			
			if (0 < size) {
				
				By webElementLocator = By.xpath("//*[contains(@name, 'additionalAccounts')]");
				
				List<WebElement> list = driver.findElements(webElementLocator);
				
				System.out.println("list size--------------"+list.size());
				
				if(null != list && !list.isEmpty()){
				
					for (int i = 0; i < size; i++) {
						
						list.get(i).sendKeys(accNums[i].trim());
					}
				}
			}
		}
	}
	
	public void clickNextBtn(){
		driver.findElement(By.id("nextButton")).submit();
	}
	
	public void clickAddLots(){
		By webElementLocator = By.xpath("//*[contains(@id, '_add_lots_link')]");
		AppWebElements.waitForElement(driver, webElementLocator, AppConstants.ELEMENT_WAIT_TIME);
		driver.findElement(webElementLocator).click();		
	}	
}
