package com.ubs.pawa.ui.test.selenium;

import static org.junit.Assert.assertTrue;

import java.net.URISyntaxException;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.ubs.pawa.ui.test.common.AppWebElements;

public class VerificationPage {
	
	public WebDriver driver;
	
	AppWebElements appWebElements = new AppWebElements();
	
	public List<Map<String, String>> list = Collections.emptyList();

	public VerificationPage(WebDriver driver) {
		this.driver = driver;
	}
	
	public void verifyData(){
		
		AppWebElements.waitForPageLoad(driver);
		
		String actualText = driver.findElement(By.xpath("/html/body/form/table[1]/tbody/tr[1]/td/label")).getText();
		String expectedText = AppWebElements.getPropertyValue("label.text").trim();
		
		assertTrue("Review Page should be display.",	expectedText.equals(actualText));
	}
	
	public void submitRequest(){
		driver.findElement(By.id("nextButtonWithStatus")).click();
	}

	public void verifyWithRequestId() throws InterruptedException, URISyntaxException {
		
		AppWebElements.waitForPageLoad(driver);
		
		String actualText = driver.findElement(By.xpath("/html/body/table[2]/tbody/tr[1]/td")).getText();
		String expectedText = AppWebElements.getPropertyValue("lable.confirm").trim();
		
		assertTrue("Confirmation Page should be display.",	expectedText.equals(actualText));		
		
		getRequestId();
	}
	
	public void getRequestId() throws InterruptedException, URISyntaxException{
		
		String message = driver.findElement(By.id("outcomeScreenServiceWorksId")).getText();
		
		int hashIndex = message.indexOf('#');
		
		String requestId = message.substring(hashIndex+1, hashIndex+9);
		
		Thread.sleep(3000);
		
		//System.out.println(hashIndex+"======"+message+"------------------"+requestId);
		
		if(StringUtils.isNotBlank(requestId.trim())){
			verifyRequestId(requestId);
		}
	}
	
	public void verifyRequestId(String requestId) throws InterruptedException, URISyntaxException{		
				
		String finalUrl = AppWebElements.getPropertyValue("request.url").trim().concat(requestId);
		
		driver.get(finalUrl);
		
		driver.manage().window().maximize();
		
		String actualText = driver.findElement(By.xpath("//table[@id='mainDisplay']/tbody/tr[1]/td/label")).getText().trim();
		
		String actualRequestId = actualText.substring(actualText.indexOf("#")+1).trim();
		
		System.out.println(actualRequestId);
		
		assertTrue("Generated requestId is : "+requestId+" and found : "+actualRequestId,	requestId.equals(actualRequestId));
		
		Thread.sleep(3000);		
	}
}
