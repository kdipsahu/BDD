package com.ubs.pawa.ui.test.stepDefinition;

import java.net.URISyntaxException;

import org.openqa.selenium.WebDriver;

import com.ubs.pawa.ui.test.common.AppWebDriver;
import com.ubs.pawa.ui.test.common.AppWebElements;
import com.ubs.pawa.ui.test.selenium.HomePage;
import com.ubs.pawa.ui.test.selenium.LoginPage;
import com.ubs.pawa.ui.test.selenium.VerificationPage;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class PawaStepDef {

	public WebDriver driver;

	public LoginPage loginPage;

	public HomePage homePage;
	
	public VerificationPage verificationPage;
	
	AppWebDriver appWebDriver = new AppWebDriver();

	@Before
	public void loadDriver() throws InterruptedException, URISyntaxException {
		driver = appWebDriver.loadAndLaunchApp();
		loginPage = new LoginPage(driver);		
		homePage = new HomePage(driver);
		verificationPage = new VerificationPage(driver);
	}

	@Given("^User is on Login page$")
	public void user_is_on_login_page() throws Throwable {
		loginPage.verifyLoginPage();
	}

	@When("^User enters Account as \"(.*?)\"$")
	public void user_enters_account_as(String accountNum) throws Throwable {
		loginPage.executeLogin(accountNum);
	}

	@When("^User clicks on Go button$")
	public void user_clicks_on_go_button() throws Throwable {
		loginPage.submitRequest();
	}

	@Then("^User verify Home page$")
	public void user_verify_home_page() throws Throwable {
		loginPage.verifyHomePage();
	}
	
	@Then("^User select date range as \"(.*?)\" and \"(.*?)\"$")
	public void user_select_date_range_as_and(String fromDate, String toDate) throws Throwable {	    
		homePage.setFromDate(fromDate);		
		homePage.setToDate(toDate);		
		homePage.submitRequest();
	}
	
	@Then("^User clicks on ViewLots$")
	public void user_clicks_on_ViewLots() throws Throwable {
		AppWebElements.waitForPageLoad(driver);
	    homePage.viewLots();
	}

	@Then("^User edits the lot details as in \"(.*?)\"$")
	public void user_edits_the_lot_details_as_in(String fileName) throws Throwable {
		homePage.updateLotDetails(fileName);
	}
	
	@Then("^User select Transferred to other accounts as \"(.*?)\" and numbers as \"(.*?)\"$")
	public void user_select_Transferred_to_other_accounts_as_and_numbers_as(String transferLots, String accNum) throws Throwable {
		homePage.transferLots(transferLots, accNum);
	}
	
	@Then("^User clicks on Next button$")
	public void user_clicks_on_Next_button() throws Throwable {
		homePage.clickNextBtn();
		Thread.sleep(6000);
	}

	@When("^User verify the changes$")
	public void user_verify_the_changes() throws Throwable {
		verificationPage.verifyData();
	}

	@When("^User submit the request$")
	public void user_submit_the_request() throws Throwable {
		verificationPage.submitRequest();
	}
	
	@Then("^User verify the final result$")
	public void user_verify_the_final_result() throws Throwable {
		verificationPage.verifyWithRequestId();
	}
	
	@Then("^User clicks on AddLots$")
	public void user_clicks_on_AddLots() throws Throwable {
		homePage.clickAddLots();
	}
	
	@Then("^User add the lot details as in \"(.*?)\"$")
	public void user_add_the_lot_details_as_in(String fileName) throws Throwable {
		homePage.updateLotDetails(fileName);
	}
	
	@Then("^User delete the lot details as in \"(.*?)\"$")
	public void user_delete_the_lot_details_as_in(String fileName) throws Throwable {
		homePage.updateLotDetails(fileName);
	}
	
	@After
	public void releaseDriver() throws InterruptedException {
		appWebDriver.releaseDriver();
	}
}
