package com.ubs.pawa.ui.test.suite;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(
        features = "classpath:features",
        glue = "com.ubs.pawa.ui.test.stepDefinition",
        plugin={"pretty", "html:target/test-reports","json:target/test-reports/cucumber.json"}
        )

public class TestRunner {

}
