package com.ubs.pawa.ui.test.common;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.apache.commons.lang3.StringUtils;
import org.junit.Assert;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
 
import com.ubs.pawa.ui.test.common.AppConstants;

public class AppWebElements {
	
	// Method defined to read the properties file
	public static String getPropertyValue(String key) {

		Properties properties = new Properties();

		String value = null;

		try {
			properties.load(AppWebElements.class.getResourceAsStream(AppConstants.PROP_FILE_PATH));

			value = properties.getProperty(key).trim();

		} catch (FileNotFoundException e) {
			e.printStackTrace();

		} catch (IOException e) {
			e.printStackTrace();
		}
		return value;
	}
	
	public static void waitForPageLoad(WebDriver driver)
	{
	    ExpectedCondition<Boolean> expectation = new ExpectedCondition<Boolean>() 
	    {
	        public Boolean apply(WebDriver driver)
	        {
	            return ((JavascriptExecutor)driver).executeScript("return document.readyState").equals("complete");
	        }
	    };
	    Wait<WebDriver> wait = new WebDriverWait(driver,60);
	    try
	    {
	        wait.until(expectation);
	    }
	    catch(Throwable error)
	    {
	        Assert.assertFalse("Timeout waiting for Page Load Request to complete.",true);
	    }
	}

	public static void waitForElement(WebDriver driver, By webElementLocator, int seconds) {
		WebDriverWait wait = new WebDriverWait(driver, seconds);
		try {
			wait.until(ExpectedConditions.refreshed(ExpectedConditions.visibilityOfElementLocated(webElementLocator)));

		} catch (WebDriverException e) {
			wait.until(ExpectedConditions.refreshed(ExpectedConditions.visibilityOfElementLocated(webElementLocator)));
		}
	}
	
	public static void changeHiddenField(WebDriver driver, String id, String value){
		
		JavascriptExecutor jse = (JavascriptExecutor)driver;
		jse.executeScript("document.getElementById('"+id+"').setAttribute('type', 'text');");
		
		driver.findElement(By.id(id)).clear();
		driver.findElement(By.id(id)).sendKeys(value);		
	}	
	
	// Method to read input file
	public List<Map<String, String>> readInputFile(String fileName) {
		BufferedReader br = null;
		String strLine = "";

		List<Map<String, String>> inputTableData = new ArrayList<>();

		String filePath = AppConstants.INPUT_FILE_PATH
				+ fileName + AppConstants.FILE_EXTENSION;
		
		System.out.println("Input file complete path :"+filePath);
		try {
			URL fileUrl = getClass().getResource(filePath);
			
			Assert.assertNotNull("Input file path is incorrect",fileUrl);
			
			br = new BufferedReader(new FileReader(fileUrl.getFile()));
						
			int rowNumber = 1;
			String[] inputTableHeader = { "" };
			while ((strLine = br.readLine()) != null) {
				if (rowNumber == 1) {
					inputTableHeader = strLine.trim().split("\\|");
				} else {
					String[] tableRow = strLine.trim().split("\\|");
					Map<String, String> expectedTableRow = new HashMap<String, String>();
					for (int iterator = 0; iterator < tableRow.length; iterator++) {
						expectedTableRow.put(
								inputTableHeader[iterator].trim(),
								tableRow[iterator].trim());
					}
					inputTableData.add(expectedTableRow);
				}

				rowNumber = rowNumber + 1;
			}
			System.out.println("Input file data: "+ inputTableData.toString());
		} catch (FileNotFoundException e) {
			System.err.println("Unable to find the file: " + fileName);
		} catch (IOException e) {
			System.err.println("Unable to read the file:" + fileName);
		}
		
		Assert.assertNotNull("Input file has no data", inputTableData);
		return inputTableData;
	}
	
	public static void updateValues(WebDriver driver, List<Map<String, String>> inputTableData) {

		try {

			for (int i = 0; i < inputTableData.size(); i++) {

				String action = inputTableData.get(i).get(getPropertyValue("label.action").trim());
				
				System.out.println("action--------"+action);

				if (AppConstants.ACTION_EDIT.equals(action)) {
					
					editRecord(driver, inputTableData, i);
					
				} else if (AppConstants.ACTION_ADD.equals(action)) {
					
					addRecord(driver, inputTableData, i);
					
				} else if (AppConstants.ACTION_DELETE.equals(action)) {
					
					deleteRecord(driver, inputTableData, i);
				}
			}
		} catch (Throwable e) {
			e.printStackTrace();
		}
	}
	
	public static void editRecord(WebDriver driver, List<Map<String, String>> inputTableData, int i){

		String recordNum = inputTableData.get(i).get(getPropertyValue("label.recordNo").trim());

		System.out.println("Record No : " + recordNum);

		if (StringUtils.isNotBlank(recordNum)) {

			int recordNo = Integer.parseInt(recordNum.trim()) + 1;

			WebElement row = driver.findElement(
					By.xpath("//table[@id='transactionsAndTaxLotsTable']/tbody/tr[" + recordNo + "]"));

			String typeValue = inputTableData.get(i).get(getPropertyValue("label.type").trim());

			if (StringUtils.isNotBlank(typeValue)) {

				WebElement typeWebElement = row.findElement(By.xpath(".//*[contains(@id, '_type')]"));

				new Select(typeWebElement).selectByVisibleText(typeValue);
			}

			String lotDate = inputTableData.get(i).get(getPropertyValue("label.lotDate").trim());

			if (StringUtils.isNotBlank(lotDate)) {

				By webElementLocator = By.xpath(".//*[contains(@id, '_date')]");

				waitForElement(driver, webElementLocator, AppConstants.ELEMENT_WAIT_TIME);

				List<WebElement> dateElement = row.findElements(webElementLocator);

				String id = dateElement.get(1).getAttribute("id");

				changeHiddenField(driver, id, lotDate);
			}

			String fmvValue = inputTableData.get(i).get(getPropertyValue("label.fmv").trim());

			if (StringUtils.isNotBlank(fmvValue)) {

				By webElementLocator = By.xpath(".//*[contains(@id, '_fair_market_value')]");

				waitForElement(driver, webElementLocator, 1000);

				List<WebElement> dateElement = row.findElements(webElementLocator);

				String id = dateElement.get(1).getAttribute("id");

				changeHiddenField(driver, id, fmvValue);
			}

			String quantity = inputTableData.get(i).get(getPropertyValue("label.quantity").trim());

			if (StringUtils.isNotBlank(quantity)) {

				WebElement qtyElement = row.findElement(By.xpath(".//*[contains(@id, '_quantity')]"));

				qtyElement.clear();

				qtyElement.sendKeys(quantity);
			}

			String openingDate = inputTableData.get(i).get(getPropertyValue("label.openingDate").trim());

			if (StringUtils.isNotBlank(openingDate)) {

				WebElement openDtElement = row
						.findElement(By.xpath(".//*[contains(@id, '_opening_date')]"));

				openDtElement.clear();

				openDtElement.sendKeys(openingDate);
			}

			String costBasis = inputTableData.get(i).get(getPropertyValue("label.costBasis").trim());

			if (StringUtils.isNotBlank(costBasis)) {

				WebElement costElement = row.findElement(By.xpath(".//*[contains(@id, '_opening_value')]"));

				costElement.clear();

				costElement.sendKeys(costBasis);
			}

			String status = inputTableData.get(i).get(getPropertyValue("label.status").trim());

			if (StringUtils.isNotBlank(status)) {

				WebElement statusWebElement = row
						.findElement(By.xpath(".//*[contains(@id, '_coverage_status')]"));

				new Select(statusWebElement).selectByVisibleText(status);
			}
		}		
	}
	
	public static void addRecord(WebDriver driver, List<Map<String, String>> inputTableData, int i) {

		String recordNum = inputTableData.get(i).get(getPropertyValue("label.recordNo").trim());

		System.out.println("Record No : " + recordNum);

		if (StringUtils.isNotBlank(recordNum)) {

			int rNo = Integer.parseInt(recordNum.trim()) + 1;

			String typeValue = inputTableData.get(i).get(getPropertyValue("label.type").trim());

			if (StringUtils.isNotBlank(typeValue)) {

				WebElement typeWebElement = driver.findElement(By.xpath(".//*[contains(@id, '_tax_lot_TLID"+rNo+"_type')]"));

				new Select(typeWebElement).selectByVisibleText(typeValue);
			}

			String lotDate = inputTableData.get(i).get(getPropertyValue("label.lotDate").trim());

			if (StringUtils.isNotBlank(lotDate)) {

				By webElementLocator = By.xpath(".//*[contains(@id, '_tax_lot_TLID"+rNo+"_date')]");

				waitForElement(driver, webElementLocator, 1000);

				List<WebElement> dateElement = driver.findElements(webElementLocator);

				String id = dateElement.get(1).getAttribute("id");

				changeHiddenField(driver, id, lotDate);
			}

			String fmvValue = inputTableData.get(i).get(getPropertyValue("label.fmv").trim());

			if (StringUtils.isNotBlank(fmvValue)) {

				By webElementLocator = By.xpath(".//*[contains(@id, '_tax_lot_TLID"+rNo+"_fair_market_value')]");

				waitForElement(driver, webElementLocator, 1000);

				List<WebElement> dateElement = driver.findElements(webElementLocator);

				String id = dateElement.get(1).getAttribute("id");

				changeHiddenField(driver, id, fmvValue);
			}

			String quantity = inputTableData.get(i).get(getPropertyValue("label.quantity").trim());

			if (StringUtils.isNotBlank(quantity)) {

				WebElement qtyElement = driver.findElement(By.xpath(".//*[contains(@id, '_tax_lot_TLID"+rNo+"_quantity')]"));

				qtyElement.clear();

				qtyElement.sendKeys(quantity);
			}

			String openingDate = inputTableData.get(i).get(getPropertyValue("label.openingDate").trim());

			if (StringUtils.isNotBlank(openingDate)) {

				WebElement openDtElement = driver
						.findElement(By.xpath(".//*[contains(@id, '_tax_lot_TLID"+rNo+"_opening_date')]"));

				openDtElement.clear();

				openDtElement.sendKeys(openingDate);
			}

			String costBasis = inputTableData.get(i).get(getPropertyValue("label.costBasis").trim());

			if (StringUtils.isNotBlank(costBasis)) {

				WebElement costElement = driver
						.findElement(By.xpath(".//*[contains(@id, '_tax_lot_TLID"+rNo+"_opening_value')]"));

				costElement.clear();

				costElement.sendKeys(costBasis);
			}

			String status = inputTableData.get(i).get(getPropertyValue("label.status").trim());

			if (StringUtils.isNotBlank(status)) {

				WebElement statusWebElement = driver
						.findElement(By.xpath(".//*[contains(@id, '_tax_lot_TLID"+rNo+"_coverage_status')]"));

				new Select(statusWebElement).selectByVisibleText(status);
			}
		}
	}
	
	public static void deleteRecord(WebDriver driver, List<Map<String, String>> inputTableData, int i) {

		String recordNum = inputTableData.get(i).get(getPropertyValue("label.recordNo").trim());

		System.out.println("Record No : " + recordNum);

		if (StringUtils.isNotBlank(recordNum)) {
			
			int recordNo = Integer.parseInt(recordNum.trim()) + 1;

			WebElement row = driver.findElement(
					By.xpath("//table[@id='transactionsAndTaxLotsTable']/tbody/tr[" + recordNo + "]"));
			
			WebElement deleteElement = row.findElement(By.xpath(".//td/a[text()='Delete']"));
			
			deleteElement.click();			
		}
	}
}
