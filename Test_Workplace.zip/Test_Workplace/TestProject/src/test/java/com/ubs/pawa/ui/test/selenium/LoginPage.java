package com.ubs.pawa.ui.test.selenium;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;

import com.ubs.pawa.ui.test.common.AppConstants;
import com.ubs.pawa.ui.test.common.AppWebElements;

public class LoginPage {

	private final WebDriver driver;

	AppWebElements appWebElements = new AppWebElements();

	public LoginPage(WebDriver driver) {

		this.driver = driver;
	}
	
	public void verifyLoginPage() {

		Wait<WebDriver> wait = new FluentWait<WebDriver>(driver).withTimeout(30, TimeUnit.SECONDS).pollingEvery(2, TimeUnit.SECONDS);

		wait.until(ExpectedConditions.titleIs(AppConstants.LOGIN_PAGE_TITLE));

		System.out.println("Verify the Login Page.");
	}

	// Execute login
	public void executeLogin(String accountNum) {

		System.out.println("On Login page");

		driver.findElement(By.id("account")).sendKeys(accountNum);		
	}

	// Submit request
	public void submitRequest() {
		driver.findElement(By.id("go")).submit();
	}

	// Verify Home page
	public void verifyHomePage() {
		
		Wait<WebDriver> wait = new FluentWait<WebDriver>(driver).withTimeout(30, TimeUnit.SECONDS).pollingEvery(2, TimeUnit.SECONDS);

		wait.until(ExpectedConditions.titleIs(AppConstants.HOME_PAGE_TITLE));

		System.out.println("Verify the Home Page.");
	}
}
