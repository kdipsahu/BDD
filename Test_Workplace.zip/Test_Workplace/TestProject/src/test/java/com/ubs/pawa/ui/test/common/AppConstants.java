package com.ubs.pawa.ui.test.common;

public class AppConstants {

	// General Constants
	
	public static final String PROP_FILE_PATH = "/appProperties.properties";
	
	public static final long WEB_DRIVER_WAIT_TIME = 10;

	public static final long THREAD_SLEEP_TIME = 10000;
	
	public static final int ELEMENT_WAIT_TIME = 1000;
	
	public static final String LOGIN_PAGE_TITLE = "PMIS ACAT Welcome Screen";
	
	public static final String HOME_PAGE_TITLE = "PMIS ACAT Entry Screen for ACAT"; 
	
	public static final String INPUT_FILE_PATH = "/inputFiles/";
	
	public static final String OUTPUT_FILE_PATH = "/outputFiles/";

	public static final String FILE_EXTENSION = ".txt";
	
	public static final String TRANSFER_LOTS_YES = "Yes";
	
	public static final String ACTION_EDIT = "Edit";

	public static final String ACTION_ADD = "Add";

	public static final String ACTION_DELETE = "Delete";	
}
