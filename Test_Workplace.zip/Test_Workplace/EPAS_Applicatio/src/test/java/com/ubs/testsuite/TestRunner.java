package com.ubs.testsuite;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(
        	features = "classpath:feature",
        	glue = "com.ubs.stepDefinition",
        	tags ="@InternetApp",
        	plugin={"pretty", "html:target/cucumber"}
        )

public class TestRunner {

}
