package com.ubs.internetFunctionalities;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.WebElement;

import java.awt.AWTException;
//import java.awt.Robot;
//import java.awt.event.KeyEvent;

public class functionality {

	public static String ph_no;
	public static WebDriver driver;
	
	public void launchApplication(WebDriver pass_driver) throws InterruptedException{
		// Assign the driver instance
		driver = pass_driver;
		// Launch Internet Application
		driver.get("https://xashcef04dap.ash.pwj.com:9443/CEFSWebApp/start.do");
		driver.manage().window().maximize();
		// If IE browser then apply the below code
		//driver.get("javascript:document.getElementById('overridelink').click();");
	}
	
	public void enterCompany(String company){	
		// Enter Company Name
		driver.findElement(By.xpath("//input[@name='ticker']")).sendKeys(new String[] { company });
		// Click on the submit button
		driver.findElement(By.xpath("//input[@value='submit']")).submit();
	}
	
	public void enterUidPwd(String username){
		// Enter User ID
		driver.findElement(By.xpath("//input[@name='opt_id']")).sendKeys(new String[] { username });
		// Enter Password
		driver.findElement(By.xpath("//input[@name='opt_pin']")).sendKeys(new String[] { "ubs123" });
	}
	
	public void clickLogIn(){
		// Click LogIn Button
		driver.findElement(By.xpath("//p[text()='Login']")).click();
	}
	public void clickMyProfile(){
		// Click on the My Profile link
		driver.findElement(By.linkText("My Profile")).click();
	}
	
	public void selectCountry(String country) throws AWTException{
		
		/*WebElement e_country = driver.findElement(By.xpath("//div[@id='ext-gen10']/input[@id='ext-gen9']"));
		e_country.clear();
		//Select Country
		e_country.sendKeys(new String[] { country });*/
		
		driver.findElement(By.xpath("//img[@id='ext-gen11']")).click();
		driver.findElement(By.xpath("//div[@id='ext-gen32']/div[text()='"+country+"']")).click();
		//Robot robot = new Robot();
		//robot.keyPress(KeyEvent.VK_ENTER);
	}
	
	public void eneterPhNo(String ph_no){
		// Enter Number
		driver.findElement(By.xpath("//input[@name='home_number']")).sendKeys(new String[] { ph_no });
	}
	
	public void checkPhNo(){
        // Store the entered phone number is ph_no variable to validate
		ph_no = driver.findElement(By.xpath("//input[@name='home_number']")).getAttribute("value");		
		// To check the number contains only numeric values
		if((ph_no.matches("[0-9]+")) && (ph_no.length() < 11)){
			
			System.out.println("You have entered a valid phone numnber...");
		}
	}
}