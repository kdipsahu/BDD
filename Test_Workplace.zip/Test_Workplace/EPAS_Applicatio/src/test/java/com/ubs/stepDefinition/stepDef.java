package com.ubs.stepDefinition;

import org.openqa.selenium.WebDriver;

//import org.openqa.selenium.ie.InternetExplorerDriver;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;

import com.ubs.internetFunctionalities.functionality;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class stepDef {
	
	public WebDriver driver;
	
	public functionality obj_func = new functionality();
	
	@Before
	public void driverInitialize(){
		
		// IE Browser
		//System.setProperty("webdriver.ie.driver", "C:/Users/kx00822/Downloads/IEDriverServer.exe");
		//driver = new InternetExplorerDriver();
		
		// Chrome Browser
		DesiredCapabilities cap=DesiredCapabilities.chrome();
		cap.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
		System.setProperty("webdriver.chrome.driver","C:/Users/kx00822/Downloads/chromedriver.exe");
		driver = new ChromeDriver(cap);
	}
	
	@Given("^user is on application homepage$")
	public void user_is_on_application_homepage() throws Throwable {
	    
		obj_func.launchApplication(driver);
	}

	@When("^user enters the company as \"(.*?)\"$")
	public void user_enters_the_company_as(String company) throws Throwable {
	    
	    obj_func.enterCompany(company);
	}

	@When("^use enters the username as \"(.*?)\"$")
	public void use_enters_the_username_as(String username) throws Throwable {
	    
		obj_func.enterUidPwd(username);
	}

	@When("^user clicks on the login button$")
	public void user_clicks_on_the_login_button() throws Throwable {
	    
		obj_func.clickLogIn();
	}

	@When("^user clicks on the My Profile link$")
	public void user_clicks_on_the_My_Profile_link() throws Throwable {
	    
		obj_func.clickMyProfile();
	}

	@When("^user select country as \"(.*?)\"$")
	public void user_select_country_as(String country) throws Throwable {
	    
		obj_func.selectCountry(country);
		System.out.println("hello");
	}

	@When("^uset enters the phone number as \"(.*?)\"$")
	public void uset_enters_the_phone_number_as(String ph_no) throws Throwable {
	    
		obj_func.eneterPhNo(ph_no);
	}

	@Then("^user check the entered phone number$")
	public void user_check_the_entered_phone_number() throws Throwable {
	    
		obj_func.checkPhNo();
	}

	@After
	public void closeBrowser(){
		//driver.quit();
		System.out.println("END");
	}


}
