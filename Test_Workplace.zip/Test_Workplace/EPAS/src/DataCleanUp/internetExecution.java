package DataCleanUp;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.support.ui.Select;

public class internetExecution {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		
		// URL - https://xashcef04dap.ash.pwj.com:9443/CEFSWebApp/start.do
		// AET
		// 2101307 and ubs123
		
		System.setProperty("webdriver.ie.driver", "C:/Users/kx00822/Downloads/IEDriverServer.exe");
		WebDriver driver = new InternetExplorerDriver();
		
		driver.get("https://xashcef04dap.ash.pwj.com:9443/CEFSWebApp/start.do");
		driver.manage().window().maximize();
		Thread.sleep(3000);
		
		driver.findElement(By.xpath("//input[@name='ticker']")).sendKeys(new String[] { "AET" });
		
		driver.findElement(By.xpath("//input[@value='submit']")).submit();
		
		// Enter User ID
		driver.findElement(By.xpath("//input[@name='opt_id']")).sendKeys(new String[] { "100KSDS" });
		
		// Enter Password
		driver.findElement(By.xpath("//input[@name='opt_pin']")).sendKeys(new String[] { "ubs123" });
		
		// Click LogIn Button
		driver.findElement(By.xpath("//p[text()='Login']")).click();
		
		// Click on the My Profile link
		driver.findElement(By.linkText("My Profile")).click();
		
		//Select Country
		WebElement country = driver.findElement(By.xpath("//input[@id='ext-gen9']"));
		Select dropdown = new Select(country);
		dropdown.selectByVisibleText("INDIA (091)");
		
		// Enter Number
		driver.findElement(By.xpath("//input[@name='home_number']")).sendKeys(new String[] { "ubs123" });
		// Get the entered number and store in a string variable
		String ph_no = driver.findElement(By.xpath("//input[@name='home_number']")).getAttribute("value");
		
		// To check the number contains only numeric values
		if(ph_no.matches("[0-9]+")){
			
			System.out.println("You have entered a valid phone numnber...");
		}
		
		

	}

}
