package DataCleanUp;

public class test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String str = "15 581582";
		
		if (str.matches("[0-9]+")){
			System.out.println("HI");
		}
		else
			System.out.println("Hello");
	}

}
