package TestNgTest;

import org.testng.annotations.Test;

public class TestAfterTest{


@Test
  public void f1() {
	  System.out.println("Method F1...");
  }
  
@Test
  public void f2() {
	  System.out.println("Method F2...");
  }


}
