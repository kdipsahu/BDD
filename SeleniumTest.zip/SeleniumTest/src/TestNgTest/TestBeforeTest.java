package TestNgTest;

import TestNgTest.CallTest;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;


public class TestBeforeTest {
 
	static int n =1;
  @Test
  public void beforeTest() {
	  CallTest ob = new CallTest();
	  System.out.println("Before Test");
	  if(n<=2)
		  ob.call_f();
  }
  
  @AfterMethod
  public void test()
  {
	  System.out.println("After Method Test....");
  }
  
  @Test
  public void c_test(){
	  System.out.println("Test....");
  }

}
