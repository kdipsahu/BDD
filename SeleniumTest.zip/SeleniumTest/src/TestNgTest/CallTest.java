package TestNgTest;




import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import TestNgTest.TestAfterTest;


public class CallTest {
	
	@Test
  public void call_f() {
	 // TestAfterTest ob = new TestAfterTest();
	  System.out.println("calling f func");
	  //ob.f1();
	  //ob.f2();	  
  }
  

}
