package TestPkg;

import java.io.*;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.ITestResult;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class DemoProject {
	
  @BeforeTest
  
  public void readExcel() throws IOException{
	  
	  FileInputStream ins = new FileInputStream("./WorkFlow.xlsx");
	  Workbook w_book = new XSSFWorkbook(ins);
	  Sheet st = w_book.getSheet("TC_01");
	  int rowCount = st.getLastRowNum()-st.getFirstRowNum();
	  System.out.println("Total Row.."+ rowCount);
//	  Row row = st.getRow(2);
//	  String stag = row.getCell(1).getStringCellValue();
//	  System.out.println("test.."+stag);
//	  System.out.println(row.getLastCellNum());
	  
	  System.out.println(st.getRow(3).getCell(0).getStringCellValue());
	  
//	  for (int i = 1; i < rowCount+1; i++) {
//		  
//		  Row row = st.getRow(i);
//	 
//	        //Create a loop to print cell values in a row
//	 
//	        for (int j = 0; j < row.getLastCellNum(); j++) {
//	 
//	            //Print excel data in console
//	 
//	            System.out.print(row.getCell(j).getStringCellValue()+"|| ");
//	 
//	        }
//	 
//	        System.out.println();
//	 
//	    }
	  
	  ins.close();
  }
  
  @Test
  public void Click_HyperLink(String desc, String xpath) {
	  
  }
  
  @Test
  public void Select_DropDown(String desc, String xpath, String value) {
	  
  }

  @Test
  public void Select_Text(String desc, String xpath, String value) {
	  
  }

  @Test
  public void Click_Button() {
	  
  }
 
}

