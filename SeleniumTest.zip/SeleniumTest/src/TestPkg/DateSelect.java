package TestPkg;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class DateSelect {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		
		WebDriver driver = new FirefoxDriver();
		driver.get("http://demos.telerik.com/kendo-ui/datetimepicker/index");
		driver.manage().window().maximize();
		WebDriverWait wait = new WebDriverWait(driver,3000);
		
		WebElement cal = driver.findElement(By.xpath("//span[@class='k-icon k-i-calendar']"));
		cal.click();
		WebElement e_link= driver.findElement(By.xpath("//div[@class='k-header']/a[@class='k-link k-nav-next']"));
				
		WebElement month_year = driver.findElement(By.xpath("//a[@href='#' and @class='k-link k-nav-fast']"));
		String month_yr = month_year.getText();
		System.out.println("Month & Year .." + month_yr);
		while(!((month_yr).equals("MARCH 2016"))){
			
			wait.until(ExpectedConditions.visibilityOf(month_year));
			//System.out.println("Entry.." + month_yr);
			
			e_link.click();
			//Thread.sleep(2000);
			wait.until(ExpectedConditions.elementToBeClickable(cal));
			cal.click();
			month_year = driver.findElement(By.xpath("//a[@href='#' and @class='k-link k-nav-fast']"));
			//wait.until(ExpectedConditions.visibilityOf(month_year));
			System.out.println("Entry.." + month_year.getText());
			
			if((month_year.getText().equals("MARCH 2016"))){
				break;
			}
		
		}
		
/*		while(!((month_yr).equals("MARCH 2016"))){
			
			System.out.println("Entry.." + month_year.getText());
			
			wait.until(ExpectedConditions.visibilityOf(month_year));
			//e_link.click();
			
			WebElement act_month_year = driver.findElement(By.xpath("//a[@href='#' and @class='k-link k-nav-fast']"));
			if((act_month_year.getText()).equals("MARCH 2016")){
				System.out.println("Month and Year.."+ act_month_year.getText());
				break;
			}
			System.out.println("Month and Year.."+ act_month_year.getText());
		}

		
		/*
		while(!((month_year.getText()).equals("MARCH 2016"))){
			System.out.println("Entry.." + month_year.getText() );
			WebElement e_link= driver.findElement(By.xpath("//div[@class='k-header']/a[@class='k-link k-nav-next']"));
			//wait.until(ExpectedConditions.visibilityOf(e_link));
			e_link.click();
			System.out.println("Test Clicked ..");
			cal.click();
			WebElement act_month_year = driver.findElement(By.xpath("//a[@href='#' and @class='k-link k-nav-fast']"));
			if((act_month_year.getText()).equals("MARCH 2016")){
				System.out.println("Month and Year.."+ act_month_year.getText());
				break;
			}
			System.out.println("Month and Year.."+ act_month_year.getText());
		} */
		
		
		
//		WebElement dateTable = driver.findElement(By.xpath("//table[@class='k-content']"));
//		
//		List<WebElement> dateRow = dateTable.findElements(By.tagName("tr"));
//		System.out.println("Row Size.."+ dateRow.size());
//		
//		for(WebElement row : dateRow){
//			
//			List<WebElement> colPerRow = row.findElements(By.tagName("td"));
//			
//			for(WebElement col: colPerRow){
//				
//				System.out.println("Data"+ col.getText());
//			}
//		}
		
//		List<WebElement> dateTable = driver.findElements(By.xpath("//table[@class='k-content']"));
//		
//		for(WebElement e: dateTable){
//			
//			System.out.println("Data.."+ e.getText());
//		}
//		
	}

}
