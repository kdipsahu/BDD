package TestPkg;

import org.testng.ITestResult;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.AfterMethod;


public class TestNg_Test{

  @Test
  public void f() {
	  int n = 10/2;
	  System.out.println("The number"+ n);
  }
  @BeforeMethod
  public void beforeMethod() {
	  System.out.println("Before Method");
  }

  @AfterMethod
  public void afterMethod(ITestResult tr)  {
	  System.out.println("After Method");
	  System.out.println("Status.."+tr.getStatus());
	  System.out.println("Method Name"+tr.getName());
  }


}

  