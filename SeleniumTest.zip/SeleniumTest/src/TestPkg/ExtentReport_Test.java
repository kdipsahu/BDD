package TestPkg;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

public class ExtentReport_Test {

		static ExtentReports extent;
		
		static ExtentTest test ;
	    public static void main(String[] args) {
	    	
	    	WebDriver driver = new FirefoxDriver();
	    	driver.get("http://www.makemytrip.com/flights");
	    	driver.manage().window().maximize();
	    	
	    	String file_path = "./ExtentReportsTest.html";
	    	
	        extent = new ExtentReports(file_path);

	        // creates a toggle for the given test, adds all log events under it    
	        test = extent.startTest("My First Test");

	        // log(LogStatus, details)
	        test.log(LogStatus.PASS, "This step shows usage of log(logStatus, details)");

	        // report with snapshot
	        String desc="HomePage";
	        String img = test.addScreenCapture(CaptureScreen(driver,"./ReportT/"+desc));
	        
	        test.log(LogStatus.INFO, "Image","Image example: " + img);
	        
	        test.log(LogStatus.FAIL, "This step shows usage of log(logStatus, details)");
	        // calling flush writes everything to the log file
	        extent.flush();
	        
	        test = extent.startTest("My Second Test", "Sample description");

	        // log(LogStatus, details)
	        test.log(LogStatus.PASS, "This step shows usage of log(logStatus, details)");
	        
	        extent.flush();
	    }
	    
	    public static String CaptureScreen(WebDriver driver, String ImagesPath)
	    {
	        File src_file = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
	        File oDest = new File(ImagesPath+".jpg");
	        try {
	        		FileUtils.copyFile(src_file, oDest);
	        } catch (IOException e) {
	        	System.out.println(e.getMessage());
	        }
	        return ImagesPath+".jpg";
	    }
	    
}
