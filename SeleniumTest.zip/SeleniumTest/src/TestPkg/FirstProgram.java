package TestPkg;

import java.io.File;
import java.io.IOException;
import java.util.*;


import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

public class FirstProgram {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Create a new instance of Firefox Browser
	       WebDriver driver = new FirefoxDriver();

	       //Open the URL in firefox browser
	       driver.get("http://www.naukri.com");

	       //Maximize the Browser window
	       driver.manage().window().maximize();

	       //Get the current page URL and store the value in variable 'str'
	       String str = driver.getCurrentUrl();

	       //Print the value of variable in the console
	       System.out.println("The current URL is " + str);
	       
	       
	       
	       Set<String> allwindows = driver.getWindowHandles();
	       
	       for (String currentwindow : allwindows){
	    	   driver.switchTo().window(currentwindow);
	    	   System.out.println("Window Title is "+ driver.getTitle());
	    	   if (driver.getTitle().equals("Alstom")){
	    		   WebElement img_link = driver.findElement(By.xpath("//a[@href='http://w28.naukri.com/advertiser/bms_hits.php?banner=3224245']"));
	    		   System.out.println("Sub Window");
	    		   img_link.click();
	    		   File srcFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
	    		   try {
	    			   FileUtils.copyFile(srcFile ,new File("C:\\Users\\kx00822\\workspace\\SeleniumTest\\SS.jpg"));
	    		   } catch (IOException e) {
					// TODO Auto-generated catch block
	    			   e.printStackTrace();
	    		   }

	    	   }
	       }
	       
	}

}
