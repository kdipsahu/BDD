package DemoProject;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
//import org.testng.annotations.Test;


public class ReadExcel {
  
    Workbook wbWorkbook;
    Sheet st;
	FileInputStream fs;
	
    //@Test
	public void openSheet(String filePath) {
		try {
			fs = new FileInputStream(filePath);
			Workbook w_book = new XSSFWorkbook(fs);
			st = w_book.getSheet("TC_01");

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
   // @Test
	public String getValueFromCell(int iRowNumber, int iColNumber) {
		return st.getRow(iRowNumber).getCell(iColNumber).getStringCellValue();
	}
    //@Test
	public int getRowCount() {
		return st.getLastRowNum()- st.getFirstRowNum();
	}
   // @Test
	public int getColumnCount(int row) {
		return st.getRow(row).getLastCellNum();
	}
    
    //@Test
    public void closeSheet(){
    	try {
			fs.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
	
}
