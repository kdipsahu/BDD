package DemoProject;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.IOException;

import org.testng.annotations.Test;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.support.ui.Select;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;


public class FrameworkFunction {
	
	 static WebDriver driver;
	 static ExtentReports extent;
	 static ExtentTest test;
	
	//static WebDriverWait wait;
	//static WebDriverWait wait = new WebDriverWait(driver,3000);

	@Test
	public void exe_Report() {
			try {
				String file_path = "./ExtentReports.html";		    	
		        extent = new ExtentReports(file_path);			        
			 } catch (Exception e) {
				System.out.println(e.getMessage());
		     }
		}
	
	@Test
	public void open_Browser(String desc,String browserName) {
		try {
			if (browserName.equalsIgnoreCase("FF")) {
				driver = new FirefoxDriver();
			} 
			
			
		 } catch (WebDriverException e) {
			System.out.println(e.getMessage());
	     }
	}

	@Test
	public void enter_URL(String desc, String URL) {
		driver.get(URL);
		driver.manage().window().maximize();
		generate_Report(1, desc);
	}
	
	public By locatorValue(String value) {
		By by;
		
		by = By.xpath(value);

		return by;
	}
	
	@Test
	public void enter_Text(String desc, String value, String text) throws InterruptedException {
		try {
			By locator;
			locator = locatorValue(value);
			WebElement element = driver.findElement(locator);
			//wait.until(ExpectedConditions.presenceOfElementLocated(locator));
			Thread.sleep(10);
			element.sendKeys(text);
			Robot r;
			try {
				r = new Robot();
				r.keyPress(KeyEvent.VK_TAB);
			} catch (AWTException e1) {
				e1.printStackTrace();
			}
			
			Thread.sleep(1000);
			try {
				//System.out.println("Text...->>" + element.getAttribute("value"));
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			generate_Report(1, desc);
			
		} catch (NoSuchElementException e) {
			System.err.format("No Element Found to enter text" + e);
		}
	}
	@Test
	public void click_On_Link(String desc, String value) throws InterruptedException {
		try {
			By locator;
			locator = locatorValue(value);
			WebElement element = driver.findElement(locator);
			//wait.until(ExpectedConditions.elementToBeClickable(element));
			Thread.sleep(10);
			element.click();
			generate_Report(1, desc);
		} catch (NoSuchElementException e) {
			System.err.format("No Element Found to enter text" + e);
		}
	}
	@Test
	public void click_On_Element(String desc, String value) throws InterruptedException {
		try {
			By locator;
			locator = locatorValue(value);
			WebElement element = driver.findElement(locator);
			//wait.until(ExpectedConditions.elementToBeClickable(element));
			Thread.sleep(10);
			
			if(element.getText().equals("Search Flights")){
				Thread.sleep(200);
				//((JavascriptExecutor)driver).executeScript("arguments[0].click();", element);
			}
			else{
				element.click();
			}
			generate_Report(1, desc);
			//System.out.println("To Check Click" + element.getAttribute(value));
		} catch (NoSuchElementException e) {
			System.err.format("No Element Found to perform click" + e);
		} 
	}
	@Test
	public void select_DropDown(String desc, String value, String text) throws InterruptedException {
		try {
			By locator;
			locator = locatorValue(value);
			WebElement element = driver.findElement(locator);
			Select select = new Select(element);
			//wait.until(ExpectedConditions.presenceOfElementLocated(locator));
			Thread.sleep(10);
			select.selectByValue(text);
			generate_Report(1, desc);
		} catch (NoSuchElementException e) {
			System.err.format("No Element Found to perform click" + e);
		}
	}
	
	@Test
	public void exe_Report12() {
			try {
				System.out.println("Complete...");		        
			 } catch (Exception e) {
				System.out.println(e.getMessage());
		     }
		}
	
	
	public void generate_Report(int flag,String desc){
		test = extent.startTest(desc);
		String img = test.addScreenCapture(CaptureScreen(driver,"./Report/"+desc));
		switch(flag){		
			case 1:
				test.log(LogStatus.PASS, img);
				break;
			case 0:
				test.log(LogStatus.FAIL, img);
				break;
			default:
				test.log(LogStatus.INFO, "Information Needed");
		}
		extent.flush();
	}
	
    public static String CaptureScreen(WebDriver driver, String ImagesPath)
    {
        File src_file = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
        File oDest = new File(ImagesPath+".jpg");
        try {
        		FileUtils.copyFile(src_file, oDest);
        } catch (IOException e) {
        	System.out.println(e.getMessage());
        }
        return ImagesPath+".jpg";
    }
    
 }
  
