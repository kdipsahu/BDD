package DemoProject;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class DemoTest {

	/**
	 * @param args
	 * @throws InterruptedException 
	 */
	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		
		//System.setProperty("webdriver.chrome.driver","C:/Users/kx00822/Downloads/chromedriver.exe");
		//WebDriver driver = new ChromeDriver();
		
		WebDriver driver = new FirefoxDriver();
		WebDriverWait wait = new WebDriverWait(driver,3000);
		
		driver.get("http://www.makemytrip.com/flights");
		driver.manage().window().maximize();
		
	
		
		WebElement e = driver.findElement(By.xpath("//input[@id='from_typeahead1']"));
		wait.until(ExpectedConditions.visibilityOf(e));
		e.sendKeys("HYD");
		Robot r;
		try {
			r = new Robot();
			r.keyPress(KeyEvent.VK_TAB);
		} catch (AWTException e1) {
			e1.printStackTrace();
		}
		
		Thread.sleep(1000);
		try {
			System.out.println("Text...->>" + e.getAttribute("value"));
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	   //((JavascriptExecutor) driver).executeScript("arguments[0].click();", e);
		
		//driver.close();

	}

}
