package DemoProject;

import java.util.ArrayList;
import java.util.List;

import org.testng.annotations.Test;



public class CallingValue {
	
  @Test
  public void main_func() {
	  
	    FrameworkExecution exeKey = new FrameworkExecution();
		ReadExcel excelSheet = new ReadExcel();
		excelSheet.openSheet("./Workflow.xlsx");
		for (int row = 1; row <= excelSheet.getRowCount(); row++) {
			List<Object> myParamList = new ArrayList<Object>();
			String methodName = excelSheet.getValueFromCell(row, 0);
			for (int col = 1; col < excelSheet.getColumnCount(row); col++) {
				if (!excelSheet.getValueFromCell(row, col).isEmpty()
						& !excelSheet.getValueFromCell(row, col).equals("null")) {
					myParamList.add(excelSheet.getValueFromCell(row, col));
				}
			}
			Object[] paramListObject = new String[myParamList.size()];
			paramListObject = myParamList.toArray(paramListObject);

			exeKey.runReflectionMethod("DemoProject.FrameworkFunction",methodName, paramListObject);
			
		}
		
		excelSheet.closeSheet();
   }
 	
}
